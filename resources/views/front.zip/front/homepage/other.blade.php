<div id="other">
    <div class="row">
        <div class="col-md-4">
            <div class="other_item" onclick="window.location.href='{{route('front.suites')}}'">
                <div class="other_item_image" style="background-image:url('https://lp-cms-production.imgix.net/news/2017/10/34884794003_79b7caebee_k-e1509108009678.jpg');">


                </div>
                <div class="other_item_text text-center">
                    <div class="other_item_title playfair">
                        Rooms & Suites
                    </div>
                    <div class="other_item_desc roboto">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Temporibus eius obcaecati accusantium.
                    </div>
                </div>
            </div>


        </div>
        <div class="col-md-4">
            <div class="other_item" onclick="window.location.href='{{route('front.blog',['type'=>0])}}'">
                <div class="other_item_image" style="background-image:url('https://lp-cms-production.imgix.net/news/2017/10/34884794003_79b7caebee_k-e1509108009678.jpg');">


                </div>
                <div class="other_item_text text-center">
                    <div class="other_item_title playfair">
                        Experience
                    </div>
                    <div class="other_item_desc roboto">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Temporibus eius obcaecati accusantium.
                    </div>
                </div>
            </div>


        </div>
        <div class="col-md-4">
            <div class="other_item" onclick="window.location.href='{{route('front.blog',['type'=>1])}}'">
                <div class="other_item_image" style="background-image:url('https://lp-cms-production.imgix.net/news/2017/10/34884794003_79b7caebee_k-e1509108009678.jpg');">


                </div>
                <div class="other_item_text text-center">
                    <div class="other_item_title playfair">
                        Blog
                    </div>
                    <div class="other_item_desc roboto">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Temporibus eius obcaecati accusantium.
                    </div>
                </div>
            </div>


        </div>
    </div>
</div>
